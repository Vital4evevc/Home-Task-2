# Job Service

A Spring Boot service that accepts long-running jobs over REST and runs them asynchronously on a
cluster of instances. Built on **Java 21, Spring Boot 3.5, Quartz (clustered JDBC job store) and MySQL 8.4**.
Each job simulates work with `Thread.sleep()` for a random 1–5 minutes.

---

## 1. Run it

You only need **Docker** (Docker Desktop on Windows or macOS). The jar is built inside Docker, so
you don't need a local JDK or Maven.

```bash
docker compose up --build          # MySQL + 2 app instances + nginx load balancer
```

| URL | What |
|---|---|
| `http://localhost:8080` | nginx, round-robin across both instances |
| `http://localhost:8081`, `:8082` | instance 1 / instance 2 directly |
| `localhost:3307` | MySQL (`jobs` / `jobs`) |

Demo users (HTTP Basic): `alice / alice-pass`, `bob / bob-pass`, `admin / admin-pass` (ADMIN).

For a faster demo, shorten the simulated work:

```bash
JOBS_MIN_DURATION=PT10S JOBS_MAX_DURATION=PT30S docker compose up --build
```

### Try it

> On Windows PowerShell, use `curl.exe` instead of `curl`.

```bash
# Submit (Idempotency-Key is optional; repeat the call and you get the same job back, HTTP 200)
curl -u alice:alice-pass -H "Content-Type: application/json" -H "Idempotency-Key: order-42" \
     -d '{"name":"monthly-report"}' http://localhost:8080/api/jobs

# Status (served by whichever instance nginx picks, not necessarily the one running the job)
curl -u alice:alice-pass http://localhost:8080/api/jobs/<id>

# List my jobs (admin sees everyone's)
curl -u alice:alice-pass "http://localhost:8080/api/jobs?page=0&size=20"

# Cancel (pending: cancelled at once; running: worker interrupted within ~2s, on whichever node runs it)
curl -u alice:alice-pass -X POST http://localhost:8080/api/jobs/<id>/cancel

# Exercise the retry path: first 2 attempts fail, 3rd succeeds
curl -u alice:alice-pass -H "Content-Type: application/json" \
     -d '{"name":"flaky","simulatedFailures":2}' http://localhost:8080/api/jobs

# Operational endpoints
curl http://localhost:8080/actuator/health
curl -u admin:admin-pass http://localhost:8081/actuator/prometheus | grep jobs_
```

**Failover demo:** submit a few jobs, run `docker compose kill app1`, and watch the jobs that app1 was
running get picked up by app2 (`workerInstance` changes and `attempts` goes up) after about 10s.
`docker compose stop app1` (a graceful stop) instead hands its running jobs back to the queue right away,
**without** using up an attempt.

### Tests

```bash
docker compose --profile test run --rm tests       # inside Docker, uses the host's Docker for Testcontainers
# or, with JDK 21 + Maven installed locally and Docker running:
mvn test
```

The integration tests run against a **real MySQL via Testcontainers**, so `schema.sql`, Quartz's
clustered store and the row-level race handling are exercised exactly as in production (H2 would hide
locking behaviour).

| Test | Covers |
|---|---|
| `JobApiIntegrationTest` | async submit → SUCCEEDED (the API answers while the job is still QUEUED or RUNNING); 401 on missing or wrong credentials; ownership (other user gets 404, admin gets 200); idempotent replay (200, same id), key reused with a different body (422), keys scoped per user; cancelling a **running** job; 409 when cancelling a finished job; **rate limiting** (429 + `Retry-After`); validation (400); metrics endpoint restricted to ADMIN |
| `JobExecutionIntegrationTest` | **concurrency:** 16 parallel submissions with the same key create exactly one job; 8 parallel claims of one job, exactly one wins. **Failure:** failed attempt is retried and then succeeds; retries exhausted leads to FAILED; a job orphaned by a crashed node is taken over only by Quartz recovery; recovery with no attempts left leads to FAILED; a shutdown interrupt requeues without using up an attempt; cancelling a pending job deletes its Quartz trigger |
| `SubmissionRateLimiterTest` | token bucket: burst, refill, per-user isolation (unit test, fake clock) |

---

## 2. Architecture

```mermaid
flowchart LR
    C[Client] -->|HTTPS + auth| LB[nginx / LB]
    LB --> A1
    LB --> A2
    subgraph A1[Instance 1]
        direction TB
        API1[REST API<br/>Security · Rate limit] --> SVC1[JobService]
        Q1[Quartz scheduler<br/>thread pool = N] --> W1[SimulatedWorkJob<br/>Thread.sleep]
        W1 --> EX1[JobExecutionService]
        CW1[CancellationWatcher]
    end
    subgraph A2[Instance 2]
        direction TB
        API2[REST API] --> SVC2[JobService]
        Q2[Quartz scheduler] --> W2[SimulatedWorkJob]
        W2 --> EX2[JobExecutionService]
        CW2[CancellationWatcher]
    end
    SVC1 & SVC2 & EX1 & EX2 & CW1 & CW2 --> DB[(MySQL<br/>jobs + QRTZ_* tables)]
    Q1 & Q2 <-->|row locks · check-in · recovery| DB
```

```
            ┌──────── one transaction ────────┐
POST /jobs ─▶ INSERT jobs (QUEUED)              │──▶ 201 {id, status}      (API thread is done)
            │ INSERT QRTZ trigger (fire now)  │
            └─────────────────────────────────┘
                             │  some node's Quartz acquires the trigger (cluster-wide row lock)
                             ▼
  Quartz worker thread:  UPDATE jobs SET RUNNING ... WHERE status IN (QUEUED,RETRY_PENDING)   ← CAS claim
                         Thread.sleep(1–5 min)    (no transaction or connection held)
                         UPDATE → SUCCEEDED | RETRY_PENDING (+ new trigger, backoff) | FAILED | CANCELLED
```

### Component boundaries

| Package | Responsibility |
|---|---|
| `api` | HTTP contract only: DTOs, status codes, RFC 9457 problem details. No business rules. |
| `service` | API use cases (submit, get, list, cancel), idempotency, quota, ownership checks. |
| `execution` | Everything that runs on worker threads: Quartz job, claim / complete / retry / recover state machine, cancellation watcher, graceful shutdown. Talks to Quartz only through `QuartzJobScheduler`. |
| `domain` | `Job` entity, `JobStatus` state machine, repository with **guarded UPDATEs**. |
| `security`, `ratelimit` | Cross-cutting edge concerns. |
| `observability` | Micrometer metrics. |

The `api`/`service` side and the `execution` side communicate **only through the database**, never
in memory. That makes it possible to split them later into an API deployment and a worker deployment
(same artifact, `spring.quartz.auto-startup=false` on API pods) and scale them independently.

### Job states

```
QUEUED ──▶ RUNNING ──▶ SUCCEEDED
  │          │ ├──(error, attempts left)──▶ RETRY_PENDING ──▶ RUNNING …
  │          │ └──(error, none left)──────▶ FAILED
  └──────────┴──(cancel)──▶ CANCELLED            (RETRY_PENDING can be cancelled too)
```

`jobs` is the source of truth that the API exposes. Quartz tables only hold *what fires next*.

---

## 3. Key decisions and trade-offs

**Quartz with a clustered JDBC store as the work queue.**
Quartz already solves the hard distributed parts: exactly-one-node firing (via `QRTZ_LOCKS` row locks),
durable delayed triggers (used for retry backoff), misfire handling, per-node thread pools, and
**failover**. Nodes check in every 10s, and if one stops, the others re-fire its in-flight jobs (`requestRecovery=true`).
Because Spring wires Quartz with `LocalDataSourceJobStore`, a trigger is written **in the same
transaction** as the job row. A job can't be saved without being scheduled, and there's no outbox to build.
*Trade-off:* Quartz serialises trigger acquisition on a DB lock, which is fine for thousands of jobs/hour
but not for millions. At that scale, move to a broker (Kafka/RabbitMQ/SQS) plus an outbox, with the
same `jobs` table and state machine.

**MySQL (InnoDB) for persistence.** Durable, transactional, and shared by all instances. Quartz
supports it natively, and its row locking gives us safe compare-and-set updates. The app talks to MySQL through
`mysql-connector-j`.

**Schema as one idempotent `schema.sql`, no migration tool.** Spring Boot runs `src/main/resources/schema.sql`
on every startup (`spring.sql.init.mode=always`). Every statement is `CREATE TABLE IF NOT EXISTS`, so restarts and
two instances starting at once are both safe. The Quartz tables are in the same file. Quartz's own script starts
with `DROP TABLE`, so `spring.quartz.jdbc.initialize-schema=never`. *Trade-off:* there's no schema versioning.
Additive changes (new tables) just work, but altering an existing column means a manual `ALTER` script. Once the
schema starts evolving, I'd add Flyway or Liquibase. Their versioned migrations and startup lock between instances
are what this setup gives up.

**Guarded (compare-and-set) UPDATEs instead of entity locking.** Every transition is
`UPDATE … WHERE id=? AND status IN (…) [AND worker_instance=?]` and checks the affected-row count. Quartz
should never fire a job twice, but if it does (recovery racing with a slow node, a manual re-trigger), at
most one claimer wins. The test proves this with 8 concurrent claimers. The 1–5 minute sleep runs **outside** any
transaction.

**Concurrency limits.** `JOBS_MAX_CONCURRENT_PER_INSTANCE` is the Quartz thread-pool size, so capacity
is instances × threads. Excess jobs simply wait in `QUEUED`. `jobs.limits.max-active-jobs-per-user` caps
how much of the cluster one user can queue (checked against the DB, so it applies cluster-wide).

**Idempotency.** There's an optional `Idempotency-Key` header with a unique index on `(owner, key)`. A replay with the
same body returns the original job (200). The same key with a different body gets 422. Concurrent first submissions
race on the unique index, and the loser returns the winner's job. *Trade-off:* keys never expire. In production,
add `expires_at` and a cleanup job.

**Retries.** Exponential backoff (`initial-backoff × multiplier^(n-1)`), with `max-attempts` including the
first attempt. The retry is a new Quartz trigger written in the same transaction as `RETRY_PENDING`, so
it survives restarts. `@DisallowConcurrentExecution` stops a retry from overlapping the previous attempt.

**Interrupted jobs.**
*Crash* (kill -9, OOM, lost host): Quartz recovery re-fires on a live node, `isRecovering=true` lets that
node take over the `RUNNING` row, and the attempt counts. If no attempts are left, the job goes to FAILED.
*Graceful shutdown* (deploy): running jobs are interrupted, set back to `QUEUED` **without using up an
attempt**, and given a fresh trigger, so another node starts them right away instead of waiting out a 5-minute sleep.

**Cancellation across nodes.** The request may land on node A while the job sleeps on node B. A pending
job is cancelled and its trigger deleted in one transaction. A running job gets `cancel_requested=true`, and every
node polls (one indexed query every 2s) for flagged jobs **among the ones it is executing** and calls
`Thread.interrupt()`. *Trade-off:* up to about 2s of cancellation latency, in exchange for no node-to-node messaging.
Redis pub/sub or a broker topic would make it immediate.

**Authentication and authorization.** Stateless HTTP Basic against configured users, roles USER/ADMIN.
Ownership is enforced in the service layer, and other users' jobs return **404** (not 403) so ids can't be
probed. ADMIN sees all jobs and the metrics endpoints. *Production:* replace `httpBasic()` with
`oauth2ResourceServer().jwt()` against an OIDC provider. That's a single-line change in `SecurityConfig`.

**Rate limiting.** Per-user token bucket on `POST /api/jobs` (default burst 10, then 10 per minute), returning 429 with
`Retry-After`. *Trade-off:* the buckets are in-memory per instance, so with N instances the effective limit is
up to N × the configured value. That's acceptable as edge protection, and the DB-backed active-job quota is
the cluster-wide guard. For an exact global limit, use Bucket4j with a Redis (Lettuce) proxy manager behind the
same `SubmissionRateLimiter` interface, or enforce it at the API gateway.

**Operational visibility.**
- Logs carry `jobId` in the MDC on every line written by a worker. State transitions are logged at INFO, retries at WARN, and permanent failures at ERROR.
- Metrics at `/actuator/prometheus` (ADMIN only):

  | Metric | Meaning |
  |---|---|
  | `jobs_submitted_total`, `jobs_submitted_replayed_total` | Submissions, and idempotent replays |
  | `jobs_finished_total{outcome}` | Completions by outcome |
  | `jobs_retries_total`, `jobs_recovered_total` | Retries, and jobs taken over after a node failure |
  | `jobs_submissions_rate_limited_total` | Submissions rejected by the rate limiter |
  | `jobs_execution_seconds` | Duration of each attempt |
  | `jobs_running_local` | Jobs running on this instance |
  | `jobs_count{status}` | Cluster-wide queue depth, read from the DB |
- Health checks: `/actuator/health` (includes DB) and `/actuator/health/liveness|readiness` for Kubernetes probes.

**Spring Boot 3.5 rather than 4.x.** It's the most widely deployed line, and its Testcontainers and Quartz
integrations are mature. Moving to 4.x is mechanical.

---

## 4. Implemented vs. designed

| Requirement | Status |
|---|---|
| Submit / status / cancel / list endpoints | Implemented |
| Job states, persistence across restarts | Implemented (MySQL, `schema.sql`) |
| Concurrent jobs, configurable per-instance limit, per-user quota | Implemented |
| Multiple instances, failover, graceful requeue | Implemented (clustered Quartz, Compose runs 2 nodes) |
| Idempotency, retries with backoff, interrupted/failed jobs | Implemented |
| AuthN/AuthZ | Implemented (Basic + roles + ownership). OIDC/JWT is designed only. |
| Rate limiting | Implemented per instance. Cluster-wide (Redis) is designed only. |
| Logs + metrics | Implemented. Tracing is designed only. |

### Remaining work and how I'd do it

- **Stale-RUNNING reconciler.** If the DB is unreachable at the exact moment a worker records the result,
  the row stays `RUNNING` while Quartz considers the job done. Fix: workers update a `heartbeat_at` column
  every ~30s, and a clustered Quartz cron job re-queues `RUNNING` rows whose heartbeat is older than a few
  intervals and whose `worker_instance` has no live `QRTZ_SCHEDULER_STATE` row.
- **Job timeouts.** Add `deadline_at`, and have the watcher interrupt and FAIL jobs that exceed it.
- **Results and webhooks.** Store a result reference (e.g. an S3 key), and add an optional `callbackUrl`
  delivered through an outbox with retries.
- **Priorities and fair scheduling.** Quartz trigger priority per tier, or one trigger group per tenant
  with a weighted acquisition plugin. Simpler first step: per-user concurrency caps checked at claim time.
- **Data retention.** Archive or delete terminal jobs after N days. Expire idempotency keys after 24h.
- **Tracing.** Micrometer Tracing + OpenTelemetry, propagating the trace id from the HTTP request into the
  Quartz `JobDataMap`, so a job's whole lifecycle shows up in one trace.
- **Scale beyond Quartz.** Swap the dispatch mechanism for a transactional outbox → Kafka (partitioned by
  job id) → consumers with bounded concurrency. The `jobs` table, the CAS state machine, and the API stay the same.
- **Security hardening.** TLS at the load balancer, secrets from a vault instead of YAML, an audit log of
  cancellations, and per-tenant rate tiers.

---

## 5. Configuration reference

| Env var | Default | Meaning |
|---|---|---|
| `JOBS_MAX_CONCURRENT_PER_INSTANCE` | 4 | Quartz worker threads per instance |
| `JOBS_MIN_DURATION` / `JOBS_MAX_DURATION` | PT1M / PT5M | Simulated work range |
| `JOBS_RANDOM_FAILURE_RATE` | 0.0 | Probability that an attempt fails |
| `JOBS_MAX_ATTEMPTS` | 3 | Attempts including the first |
| `JOBS_INITIAL_BACKOFF` | PT10S | First retry delay (doubles each time) |
| `JOBS_MAX_ACTIVE_PER_USER` | 20 | Max QUEUED + RUNNING + RETRY_PENDING jobs per user |
| `RATE_LIMIT_CAPACITY` / `RATE_LIMIT_PER_MINUTE` | 10 / 10 | Submission token bucket |
| `QUARTZ_CHECKIN_MS` | 10000 | Cluster heartbeat; failover happens after about this long |
| `DB_URL`, `DB_USER`, `DB_PASSWORD` | localhost | MySQL connection |
