package com.example.jobs.ratelimit;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.concurrent.atomic.AtomicLong;

import org.junit.jupiter.api.Test;

class SubmissionRateLimiterTest {

    private final AtomicLong now = new AtomicLong(0);
    private final SubmissionRateLimiter limiter = new SubmissionRateLimiter(3, 60, now::get); // 1 token/s

    @Test
    void allowsBurstUpToCapacityThenRejectsWithRetryAfter() {
        assertThat(limiter.tryAcquire("u")).isZero();
        assertThat(limiter.tryAcquire("u")).isZero();
        assertThat(limiter.tryAcquire("u")).isZero();
        assertThat(limiter.tryAcquire("u")).isEqualTo(1);
    }

    @Test
    void refillsOverTime() {
        for (int i = 0; i < 3; i++) {
            limiter.tryAcquire("u");
        }
        now.addAndGet(1_000_000_000L); // +1s => one token
        assertThat(limiter.tryAcquire("u")).isZero();
        assertThat(limiter.tryAcquire("u")).isPositive();
    }

    @Test
    void bucketsAreIndependentPerUser() {
        for (int i = 0; i < 3; i++) {
            limiter.tryAcquire("a");
        }
        assertThat(limiter.tryAcquire("a")).isPositive();
        assertThat(limiter.tryAcquire("b")).isZero();
    }
}
