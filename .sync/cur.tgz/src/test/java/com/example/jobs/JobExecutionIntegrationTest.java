package com.example.jobs;

import static org.assertj.core.api.Assertions.assertThat;
import static org.awaitility.Awaitility.await;

import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.Callable;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.stream.Collectors;

import org.junit.jupiter.api.Test;
import org.quartz.JobKey;
import org.quartz.Scheduler;
import org.springframework.beans.factory.annotation.Autowired;

import com.example.jobs.domain.Job;
import com.example.jobs.domain.JobRepository;
import com.example.jobs.domain.JobStatus;
import com.example.jobs.execution.Attempt;
import com.example.jobs.execution.JobExecutionService;
import com.example.jobs.execution.QuartzJobScheduler;
import com.example.jobs.service.JobService;
import com.example.jobs.service.SubmitJobCommand;
import com.example.jobs.service.SubmitResult;

/** Concurrency, failure and recovery scenarios, exercised against real MySQL + clustered Quartz. */
class JobExecutionIntegrationTest extends AbstractIntegrationTest {

    private static final Duration TIMEOUT = Duration.ofSeconds(45);

    @Autowired JobService jobService;
    @Autowired JobExecutionService executionService;
    @Autowired JobRepository repository;
    @Autowired QuartzJobScheduler jobScheduler;
    @Autowired Scheduler quartz;

    // ---- concurrency ------------------------------------------------------------------------

    @Test
    void concurrentDuplicateSubmissionsCreateExactlyOneJob() throws Exception {
        String key = UUID.randomUUID().toString();
        List<SubmitResult> results = runConcurrently(16,
                () -> jobService.submit("dave", key, new SubmitJobCommand("dup", 0)));

        Set<String> ids = results.stream().map(r -> r.job().getId()).collect(Collectors.toSet());
        assertThat(ids).hasSize(1);
        assertThat(results.stream().filter(SubmitResult::created).count()).isEqualTo(1);
        assertThat(repository.findByOwnerAndIdempotencyKey("dave", key)).isPresent();
    }

    @Test
    void onlyOneWorkerCanClaimAJob() throws Exception {
        // Simulates the same job being fired twice (e.g. on two nodes): the guarded UPDATE lets one win.
        Job job = pendingJobWithoutTrigger("eve", 3, 0);

        List<Optional<Attempt>> claims = runConcurrently(8, () -> executionService.start(job.getId(), false));

        List<Attempt> winners = claims.stream().flatMap(Optional::stream).toList();
        assertThat(winners).hasSize(1);
        Job claimed = repository.findById(job.getId()).orElseThrow();
        assertThat(claimed.getStatus()).isEqualTo(JobStatus.RUNNING);
        assertThat(claimed.getAttempts()).isEqualTo(1);

        executionService.succeed(winners.get(0));
        assertThat(repository.findById(job.getId()).orElseThrow().getStatus()).isEqualTo(JobStatus.SUCCEEDED);
    }

    // ---- failures and retries ---------------------------------------------------------------

    @Test
    void failedAttemptIsRetriedAndThenSucceeds() {
        String id = jobService.submit("frank", null, new SubmitJobCommand("flaky", 1)).job().getId();

        await().atMost(TIMEOUT).until(() -> status(id) == JobStatus.SUCCEEDED);
        Job job = repository.findById(id).orElseThrow();
        assertThat(job.getAttempts()).isEqualTo(2);
        assertThat(job.getLastError()).contains("Simulated failure");
    }

    @Test
    void jobFailsPermanentlyWhenRetriesAreExhausted() {
        String id = jobService.submit("frank", null, new SubmitJobCommand("broken", 10)).job().getId();

        await().atMost(TIMEOUT).until(() -> status(id) == JobStatus.FAILED);
        Job job = repository.findById(id).orElseThrow();
        assertThat(job.getAttempts()).isEqualTo(3);
        assertThat(job.getFinishedAt()).isNotNull();
    }

    // ---- interrupted jobs / node failure ----------------------------------------------------

    @Test
    void jobOrphanedByCrashedNodeIsTakenOverOnlyByRecovery() {
        Job job = pendingJobWithoutTrigger("grace", 3, 0);
        // A node that later "dies" claimed the job.
        repository.claim(job.getId(), "dead-node", 60_000, Instant.now(), JobStatus.PENDING);

        // An ordinary (duplicate) fire must not steal a job another node is running...
        assertThat(executionService.start(job.getId(), false)).isEmpty();

        // ...but Quartz cluster recovery (isRecovering=true) takes it over as the next attempt.
        Attempt attempt = executionService.start(job.getId(), true).orElseThrow();
        assertThat(attempt.number()).isEqualTo(2);
        assertThat(repository.findById(job.getId()).orElseThrow().getWorkerInstance())
                .isEqualTo(jobScheduler.instanceId());

        executionService.succeed(attempt);
        assertThat(status(job.getId())).isEqualTo(JobStatus.SUCCEEDED);
    }

    @Test
    void recoveredJobWithNoAttemptsLeftIsFailed() {
        Job job = pendingJobWithoutTrigger("grace", 1, 0);
        repository.claim(job.getId(), "dead-node", 60_000, Instant.now(), JobStatus.PENDING);

        assertThat(executionService.start(job.getId(), true)).isEmpty();
        Job failed = repository.findById(job.getId()).orElseThrow();
        assertThat(failed.getStatus()).isEqualTo(JobStatus.FAILED);
        assertThat(failed.getLastError()).contains("node failure");
    }

    @Test
    void shutdownInterruptRequeuesJobWithoutConsumingAnAttempt() {
        Job job = pendingJobWithoutTrigger("heidi", 3, 0);
        Attempt attempt = executionService.start(job.getId(), false).orElseThrow();

        executionService.interrupted(attempt, true);   // what a worker does when the node shuts down

        Job requeued = repository.findById(job.getId()).orElseThrow();
        assertThat(requeued.getStatus()).isIn(JobStatus.QUEUED, JobStatus.RUNNING, JobStatus.SUCCEEDED);
        // The requeue scheduled a fresh Quartz trigger: the job now runs to completion as attempt 1.
        await().atMost(TIMEOUT).until(() -> status(job.getId()) == JobStatus.SUCCEEDED);
        assertThat(repository.findById(job.getId()).orElseThrow().getAttempts()).isEqualTo(1);
    }

    @Test
    void cancellingPendingJobRemovesItsQuartzTrigger() throws Exception {
        Job job = pendingJobWithoutTrigger("ivan", 3, 0);
        jobScheduler.scheduleAttempt(job.getId(), Instant.now().plus(Duration.ofHours(1)));
        assertThat(quartz.checkExists(JobKey.jobKey(job.getId(), QuartzJobScheduler.GROUP))).isTrue();

        Job cancelled = jobService.cancel(job.getId(), new JobService.Caller("ivan", false));

        assertThat(cancelled.getStatus()).isEqualTo(JobStatus.CANCELLED);
        assertThat(quartz.checkExists(JobKey.jobKey(job.getId(), QuartzJobScheduler.GROUP))).isFalse();
    }

    // ---- helpers ----------------------------------------------------------------------------

    private Job pendingJobWithoutTrigger(String owner, int maxAttempts, int simulatedFailures) {
        Job job = Job.newQueued(owner, "manual", null, "hash", maxAttempts, simulatedFailures, Instant.now());
        return repository.saveAndFlush(job);
    }

    private JobStatus status(String id) {
        return repository.findById(id).orElseThrow().getStatus();
    }

    private static <T> List<T> runConcurrently(int threads, Callable<T> task) throws Exception {
        ExecutorService pool = Executors.newFixedThreadPool(threads);
        CountDownLatch go = new CountDownLatch(1);
        try {
            List<Future<T>> futures = new ArrayList<>();
            for (int i = 0; i < threads; i++) {
                futures.add(pool.submit(() -> {
                    go.await();
                    return task.call();
                }));
            }
            go.countDown();
            List<T> results = new ArrayList<>();
            for (Future<T> f : futures) {
                results.add(f.get());
            }
            return results;
        } finally {
            pool.shutdownNow();
        }
    }

}
