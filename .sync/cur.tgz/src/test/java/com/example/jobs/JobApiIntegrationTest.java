package com.example.jobs;

import static org.assertj.core.api.Assertions.assertThat;
import static org.awaitility.Awaitility.await;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.httpBasic;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.Duration;
import java.util.UUID;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

class JobApiIntegrationTest extends AbstractIntegrationTest {

    private static final Duration TIMEOUT = Duration.ofSeconds(45);

    @Autowired
    MockMvc mvc;

    @Autowired
    ObjectMapper json;

    @Test
    void unauthenticatedAndBadCredentialsAreRejected() throws Exception {
        mvc.perform(post("/api/jobs").contentType(MediaType.APPLICATION_JSON).content("{\"name\":\"x\"}"))
                .andExpect(status().isUnauthorized());
        mvc.perform(get("/api/jobs").with(httpBasic("alice", "wrong")))
                .andExpect(status().isUnauthorized());
    }

    @Test
    void submittedJobRunsAsynchronouslyToCompletion() throws Exception {
        MvcResult res = mvc.perform(submit("alice", null, "{\"name\":\"report\"}"))
                .andExpect(status().isCreated())
                .andExpect(header().exists("Location"))
                .andReturn();
        // The API answers before the work (>= 1s in tests) has finished.
        String id = body(res).get("id").asText();
        assertThat(body(res).get("status").asText()).isIn("QUEUED", "RUNNING");

        await().atMost(TIMEOUT).until(() -> "SUCCEEDED".equals(job("alice", id).get("status").asText()));
        JsonNode done = job("alice", id);
        assertThat(done.get("attempts").asInt()).isEqualTo(1);
        assertThat(done.get("result").asText()).startsWith("Completed after");
        assertThat(done.get("workerInstance").asText()).isNotBlank();
    }

    @Test
    void usersCannotSeeOrCancelOtherUsersJobsButAdminCan() throws Exception {
        String id = body(mvc.perform(submit("alice", null, "{\"name\":\"private\"}"))
                .andExpect(status().isCreated()).andReturn()).get("id").asText();

        mvc.perform(get("/api/jobs/" + id).with(httpBasic("bob", "bob-pass"))).andExpect(status().isNotFound());
        mvc.perform(post("/api/jobs/" + id + "/cancel").with(httpBasic("bob", "bob-pass")))
                .andExpect(status().isNotFound());
        mvc.perform(get("/api/jobs/" + id).with(httpBasic("admin", "admin-pass")))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.owner").value("alice"));
    }

    @Test
    void duplicateSubmissionWithSameIdempotencyKeyReturnsOriginalJob() throws Exception {
        String key = UUID.randomUUID().toString();
        String first = body(mvc.perform(submit("alice", key, "{\"name\":\"once\"}"))
                .andExpect(status().isCreated()).andReturn()).get("id").asText();

        mvc.perform(submit("alice", key, "{\"name\":\"once\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(first));

        mvc.perform(submit("alice", key, "{\"name\":\"something else\"}"))
                .andExpect(status().isUnprocessableEntity());

        // Keys are scoped per user: bob's identical key is a different job.
        mvc.perform(submit("bob", key, "{\"name\":\"once\"}"))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.owner").value("bob"));
    }

    @Test
    void runningJobCanBeCancelled() throws Exception {
        String id = body(mvc.perform(submit("alice", null, "{\"name\":\"to-cancel\"}"))
                .andExpect(status().isCreated()).andReturn()).get("id").asText();
        await().atMost(TIMEOUT).until(() -> "RUNNING".equals(job("alice", id).get("status").asText()));

        mvc.perform(post("/api/jobs/" + id + "/cancel").with(httpBasic("alice", "alice-pass")))
                .andExpect(status().isAccepted());

        await().atMost(Duration.ofSeconds(5))
                .until(() -> "CANCELLED".equals(job("alice", id).get("status").asText()));
        assertThat(job("alice", id).get("result").isNull()).isTrue();

        // A finished job cannot be cancelled again.
        mvc.perform(post("/api/jobs/" + id + "/cancel").with(httpBasic("alice", "alice-pass")))
                .andExpect(status().isConflict());
    }

    @Test
    void submissionsAreRateLimitedPerUser() throws Exception {
        int created = 0;
        int limited = 0;
        String retryAfter = null;
        for (int i = 0; i < 15; i++) {
            MvcResult r = mvc.perform(submit("carol", null, "{\"name\":\"burst-" + i + "\"}")).andReturn();
            if (r.getResponse().getStatus() == 201) {
                created++;
            } else if (r.getResponse().getStatus() == 429) {
                limited++;
                retryAfter = r.getResponse().getHeader("Retry-After");
            }
        }
        // capacity 10, refill 1/s: the burst gets ~10 through, the rest is rejected
        assertThat(created).isBetween(10, 12);
        assertThat(limited).isEqualTo(15 - created);
        assertThat(retryAfter).isNotNull();
    }

    @Test
    void invalidRequestIsRejected() throws Exception {
        mvc.perform(submit("alice", null, "{\"name\":\"\"}")).andExpect(status().isBadRequest());
    }

    @Test
    void metricsEndpointRequiresAdmin() throws Exception {
        mvc.perform(get("/actuator/prometheus").with(httpBasic("alice", "alice-pass")))
                .andExpect(status().isForbidden());
        mvc.perform(get("/actuator/health")).andExpect(status().isOk());
        MvcResult r = mvc.perform(get("/actuator/prometheus").with(httpBasic("admin", "admin-pass")))
                .andExpect(status().isOk()).andReturn();
        assertThat(r.getResponse().getContentAsString()).contains("jobs_count");
    }

    private MockHttpServletRequestBuilder submit(String user, String idempotencyKey, String content) {
        MockHttpServletRequestBuilder b = post("/api/jobs")
                .with(httpBasic(user, user + "-pass"))
                .contentType(MediaType.APPLICATION_JSON)
                .content(content);
        return idempotencyKey == null ? b : b.header("Idempotency-Key", idempotencyKey);
    }

    private JsonNode job(String user, String id) throws Exception {
        return body(mvc.perform(get("/api/jobs/" + id).with(httpBasic(user, user + "-pass")))
                .andExpect(status().isOk()).andReturn());
    }

    private JsonNode body(MvcResult r) throws Exception {
        return json.readTree(r.getResponse().getContentAsString());
    }
}
