package com.example.jobs;

import org.springframework.boot.test.autoconfigure.actuate.observability.AutoConfigureObservability;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.testcontainers.service.connection.ServiceConnection;
import org.springframework.test.context.ActiveProfiles;
import org.testcontainers.containers.MySQLContainer;

/**
 * Integration tests run against a real MySQL (Testcontainers) so schema.sql, the Quartz
 * clustered JDBC store and the guarded UPDATEs are exercised exactly as in production.
 * One container and one Spring context are shared by all test classes.
 */
@SpringBootTest
@AutoConfigureMockMvc
@AutoConfigureObservability // enables the Prometheus registry in tests
@ActiveProfiles("test")
public abstract class AbstractIntegrationTest {

    @ServiceConnection
    static final MySQLContainer<?> MYSQL = new MySQLContainer<>("mysql:8.4");

    static {
        MYSQL.start();
    }
}
