package com.example.jobs.domain;

import java.time.Instant;
import java.util.UUID;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.PostLoad;
import jakarta.persistence.PostPersist;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;

import org.springframework.data.domain.Persistable;

/**
 * A submitted job. State transitions are performed through guarded (compare-and-set) UPDATE
 * statements in {@link JobRepository}, never by mutating a loaded entity, so concurrent actors
 * (API cancellation, worker threads on several nodes, cluster recovery) cannot overwrite each other.
 */
@Entity
@Table(name = "jobs")
public class Job implements Persistable<String> {

    @Id
    @Column(length = 36)
    private String id;

    @Column(nullable = false)
    private String owner;

    @Column(nullable = false)
    private String name;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private JobStatus status;

    @Column(name = "idempotency_key")
    private String idempotencyKey;

    @Column(name = "request_hash", nullable = false)
    private String requestHash;

    private int attempts;

    @Column(name = "max_attempts")
    private int maxAttempts;

    /** Test/demo hook: the first N attempts fail deterministically. */
    @Column(name = "simulated_failures")
    private int simulatedFailures;

    @Column(name = "cancel_requested")
    private boolean cancelRequested;

    @Column(name = "worker_instance")
    private String workerInstance;

    @Column(name = "planned_duration_ms")
    private Long plannedDurationMs;

    @Column(name = "last_error")
    private String lastError;

    private String result;

    @Column(name = "created_at", nullable = false)
    private Instant createdAt;

    @Column(name = "updated_at", nullable = false)
    private Instant updatedAt;

    @Column(name = "started_at")
    private Instant startedAt;

    @Column(name = "finished_at")
    private Instant finishedAt;

    @Column(name = "next_attempt_at")
    private Instant nextAttemptAt;

    /** Assigned ids: tell Spring Data to INSERT (persist) rather than merge. */
    @Transient
    private boolean isNew = true;

    protected Job() {
        // JPA
    }

    public static Job newQueued(String owner, String name, String idempotencyKey, String requestHash,
                                int maxAttempts, int simulatedFailures, Instant now) {
        Job job = new Job();
        job.id = UUID.randomUUID().toString();
        job.owner = owner;
        job.name = name;
        job.status = JobStatus.QUEUED;
        job.idempotencyKey = idempotencyKey;
        job.requestHash = requestHash;
        job.maxAttempts = maxAttempts;
        job.simulatedFailures = simulatedFailures;
        job.createdAt = now;
        job.updatedAt = now;
        return job;
    }

    @Override
    public boolean isNew() { return isNew; }

    @PostLoad
    @PostPersist
    void markNotNew() { this.isNew = false; }

    @Override
    public String getId() { return id; }
    public String getOwner() { return owner; }
    public String getName() { return name; }
    public JobStatus getStatus() { return status; }
    public String getIdempotencyKey() { return idempotencyKey; }
    public String getRequestHash() { return requestHash; }
    public int getAttempts() { return attempts; }
    public int getMaxAttempts() { return maxAttempts; }
    public int getSimulatedFailures() { return simulatedFailures; }
    public boolean isCancelRequested() { return cancelRequested; }
    public String getWorkerInstance() { return workerInstance; }
    public Long getPlannedDurationMs() { return plannedDurationMs; }
    public String getLastError() { return lastError; }
    public String getResult() { return result; }
    public Instant getCreatedAt() { return createdAt; }
    public Instant getUpdatedAt() { return updatedAt; }
    public Instant getStartedAt() { return startedAt; }
    public Instant getFinishedAt() { return finishedAt; }
    public Instant getNextAttemptAt() { return nextAttemptAt; }
}
