package com.example.jobs.service;

/** What a caller asks for; hashed to detect Idempotency-Key reuse with a different body. */
public record SubmitJobCommand(String name, int simulatedFailures) {

    String fingerprint() {
        return name + "\u0000" + simulatedFailures;
    }
}
