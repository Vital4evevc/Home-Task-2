package com.example.jobs.service;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.Clock;
import java.time.Instant;
import java.util.HexFormat;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.PessimisticLockingFailureException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;

import com.example.jobs.config.JobProperties;
import com.example.jobs.domain.Job;
import com.example.jobs.domain.JobRepository;
import com.example.jobs.domain.JobStatus;
import com.example.jobs.execution.QuartzJobScheduler;
import com.example.jobs.observability.JobMetrics;

/** API-facing use cases: submit, query, cancel. Authorization (ownership) is enforced here. */
@Service
public class JobService {

    private static final Logger log = LoggerFactory.getLogger(JobService.class);

    private final JobRepository repository;
    private final QuartzJobScheduler scheduler;
    private final JobProperties properties;
    private final JobMetrics metrics;
    private final Clock clock;
    private final TransactionTemplate tx;

    public JobService(JobRepository repository, QuartzJobScheduler scheduler, JobProperties properties,
                      JobMetrics metrics, Clock clock, PlatformTransactionManager transactionManager) {
        this.repository = repository;
        this.scheduler = scheduler;
        this.properties = properties;
        this.metrics = metrics;
        this.clock = clock;
        this.tx = new TransactionTemplate(transactionManager);
    }

    /**
     * Creates the job row and its first Quartz trigger in ONE transaction, so a job can never be
     * persisted without being scheduled (or scheduled without being persisted).
     *
     * <p>Idempotency: (owner, Idempotency-Key) is unique in the DB. A repeat with the same body returns
     * the original job; a repeat with a different body is rejected. Two concurrent first submissions
     * race on the unique index: the loser's insert fails and it returns the winner's job.
     */
    public SubmitResult submit(String owner, String idempotencyKey, SubmitJobCommand command) {
        for (int attempt = 1; ; attempt++) {
            try {
                return trySubmit(owner, idempotencyKey, command);
            } catch (PessimisticLockingFailureException e) {
                // InnoDB deadlock victim (possible when many duplicates collide): safe to retry.
                if (attempt >= 3) {
                    throw e;
                }
                log.debug("Lock conflict on submit, retrying ({})", attempt);
            }
        }
    }

    private SubmitResult trySubmit(String owner, String idempotencyKey, SubmitJobCommand command) {
        String hash = sha256(command.fingerprint());
        try {
            return tx.execute(status -> {
                if (idempotencyKey != null) {
                    var existing = repository.findByOwnerAndIdempotencyKey(owner, idempotencyKey);
                    if (existing.isPresent()) {
                        return replay(existing.get(), idempotencyKey, hash);
                    }
                }
                long active = repository.countByOwnerAndStatusIn(owner, JobStatus.ACTIVE);
                if (active >= properties.limits().maxActiveJobsPerUser()) {
                    throw new QuotaExceededException("User has " + active + " active jobs; limit is "
                            + properties.limits().maxActiveJobsPerUser());
                }
                Instant now = clock.instant();
                Job job = Job.newQueued(owner, command.name(), idempotencyKey, hash,
                        properties.retry().maxAttempts(), command.simulatedFailures(), now);
                repository.saveAndFlush(job);          // unique index is checked here
                scheduler.scheduleAttempt(job.getId(), now);
                metrics.submitted();
                log.info("Job {} submitted by {}", job.getId(), owner);
                return new SubmitResult(job, true);
            });
        } catch (DataIntegrityViolationException e) {
            if (idempotencyKey == null) {
                throw e;
            }
            // Lost the race against a concurrent submission with the same key.
            Job winner = tx.execute(s -> repository.findByOwnerAndIdempotencyKey(owner, idempotencyKey)
                    .orElseThrow(() -> e));
            return replay(winner, idempotencyKey, hash);
        }
    }

    private SubmitResult replay(Job existing, String key, String hash) {
        if (!existing.getRequestHash().equals(hash)) {
            throw new IdempotencyConflictException(key);
        }
        metrics.replayed();
        return new SubmitResult(existing, false);
    }

    public Job get(String id, Caller caller) {
        Job job = repository.findById(id).orElseThrow(() -> new JobNotFoundException(id));
        // Non-owners get 404, not 403, so job ids of other users cannot be probed.
        if (!caller.admin() && !job.getOwner().equals(caller.username())) {
            throw new JobNotFoundException(id);
        }
        return job;
    }

    public Page<Job> list(Caller caller, Pageable pageable) {
        return caller.admin()
                ? repository.findAllByOrderByCreatedAtDesc(pageable)
                : repository.findByOwnerOrderByCreatedAtDesc(caller.username(), pageable);
    }

    /**
     * Pending jobs are cancelled synchronously (row + Quartz trigger in one transaction).
     * Running jobs are flagged; the node executing the job interrupts it within
     * {@code jobs.cancellation.poll-interval}. Returns the job as it is after the request.
     */
    public Job cancel(String id, Caller caller) {
        return tx.execute(status -> {
            Job job = get(id, caller);
            Instant now = clock.instant();
            if (JobStatus.PENDING.contains(job.getStatus())
                    && repository.markCancelled(id, JobStatus.PENDING, now) == 1) {
                scheduler.unschedule(id);
                metrics.finished(JobStatus.CANCELLED);
                log.info("Job {} cancelled before running", id);
                return repository.findById(id).orElseThrow();
            }
            // Either it was RUNNING already, or a worker claimed it between our read and update.
            if (repository.requestCancel(id, now) == 1) {
                log.info("Cancellation requested for running job {}", id);
                return repository.findById(id).orElseThrow();
            }
            Job current = repository.findById(id).orElseThrow();
            throw new InvalidJobStateException("Job " + id + " is " + current.getStatus() + " and cannot be cancelled");
        });
    }

    private static String sha256(String value) {
        try {
            byte[] digest = MessageDigest.getInstance("SHA-256").digest(value.getBytes(StandardCharsets.UTF_8));
            return HexFormat.of().formatHex(digest);
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
    }

    /** The authenticated principal, reduced to what the domain needs. */
    public record Caller(String username, boolean admin) {
    }

}
