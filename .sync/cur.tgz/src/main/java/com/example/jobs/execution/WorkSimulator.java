package com.example.jobs.execution;

import java.time.Duration;
import java.util.concurrent.ThreadLocalRandom;

import org.springframework.stereotype.Component;

import com.example.jobs.config.JobProperties;

/** Stand-in for real business processing: sleeps, and optionally fails. */
@Component
public class WorkSimulator {

    private final JobProperties.Work config;

    public WorkSimulator(JobProperties properties) {
        this.config = properties.work();
    }

    public Duration pickDuration() {
        long min = config.minDuration().toMillis();
        long max = config.maxDuration().toMillis();
        return Duration.ofMillis(ThreadLocalRandom.current().nextLong(min, max + 1));
    }

    /**
     * @param forceFailure deterministic failure requested by the submitter (demo/test hook)
     * @throws InterruptedException when the worker thread is interrupted (cancellation or shutdown)
     */
    public void perform(Duration duration, boolean forceFailure) throws InterruptedException {
        Thread.sleep(duration.toMillis());
        if (forceFailure) {
            throw new SimulatedWorkException("Simulated failure (requested by submitter)");
        }
        if (ThreadLocalRandom.current().nextDouble() < config.randomFailureRate()) {
            throw new SimulatedWorkException("Simulated random failure");
        }
    }

    public static class SimulatedWorkException extends RuntimeException {
        public SimulatedWorkException(String message) {
            super(message);
        }
    }
}
