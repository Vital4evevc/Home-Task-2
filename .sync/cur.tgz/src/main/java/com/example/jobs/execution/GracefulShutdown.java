package com.example.jobs.execution;

import java.time.Duration;

import jakarta.annotation.PreDestroy;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.example.jobs.config.JobProperties;

/**
 * On a planned shutdown (deploy, scale-in) we don't want to wait up to 5 minutes per job, nor
 * burn a retry attempt. Running jobs are interrupted and handed back to the queue (attempt not
 * counted), so another node picks them up immediately.
 *
 * <p>This bean depends on the scheduler facade, so Spring destroys it BEFORE the Quartz scheduler
 * and the DataSource: both are still usable while jobs requeue themselves.
 *
 * <p>A crash (kill -9, OOM, power loss) skips this path entirely; Quartz cluster recovery covers it.
 */
@Component
public class GracefulShutdown {

    private static final Logger log = LoggerFactory.getLogger(GracefulShutdown.class);

    private final QuartzJobScheduler scheduler;
    private final ShutdownState state;
    private final Duration maxWait;

    public GracefulShutdown(QuartzJobScheduler scheduler, ShutdownState state, JobProperties properties) {
        this.scheduler = scheduler;
        this.state = state;
        this.maxWait = properties.shutdown().requeueWait();
    }

    @PreDestroy
    public void requeueRunningJobs() {
        state.markShuttingDown();
        var running = scheduler.locallyExecutingJobIds();
        if (running.isEmpty()) {
            return;
        }
        log.info("Shutting down: handing {} running job(s) back to the queue", running.size());
        running.forEach(scheduler::interruptLocal);

        long deadline = System.nanoTime() + maxWait.toNanos();
        while (!scheduler.locallyExecutingJobIds().isEmpty() && System.nanoTime() < deadline) {
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return;
            }
        }
    }
}
