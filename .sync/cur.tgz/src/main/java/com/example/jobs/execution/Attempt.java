package com.example.jobs.execution;

import java.time.Duration;

/** One claimed execution attempt of a job on this node. */
public record Attempt(String jobId, int number, Duration duration, boolean forceFailure) {
}
