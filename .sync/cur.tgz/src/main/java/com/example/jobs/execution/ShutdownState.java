package com.example.jobs.execution;

import java.util.concurrent.atomic.AtomicBoolean;

import org.springframework.stereotype.Component;

/** Lets worker threads tell a shutdown interrupt apart from a cancellation interrupt. */
@Component
public class ShutdownState {

    private final AtomicBoolean shuttingDown = new AtomicBoolean(false);

    public boolean isShuttingDown() {
        return shuttingDown.get();
    }

    void markShuttingDown() {
        shuttingDown.set(true);
    }
}
