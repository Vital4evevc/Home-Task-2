package com.example.jobs.api;

import java.time.Instant;

import com.example.jobs.domain.Job;
import com.example.jobs.domain.JobStatus;

public record JobResponse(
        String id,
        String name,
        String owner,
        JobStatus status,
        int attempts,
        int maxAttempts,
        boolean cancelRequested,
        String workerInstance,
        Long plannedDurationMs,
        String lastError,
        String result,
        Instant createdAt,
        Instant updatedAt,
        Instant startedAt,
        Instant finishedAt,
        Instant nextAttemptAt) {

    public static JobResponse from(Job j) {
        return new JobResponse(j.getId(), j.getName(), j.getOwner(), j.getStatus(), j.getAttempts(),
                j.getMaxAttempts(), j.isCancelRequested(), j.getWorkerInstance(), j.getPlannedDurationMs(),
                j.getLastError(), j.getResult(), j.getCreatedAt(), j.getUpdatedAt(), j.getStartedAt(),
                j.getFinishedAt(), j.getNextAttemptAt());
    }
}
