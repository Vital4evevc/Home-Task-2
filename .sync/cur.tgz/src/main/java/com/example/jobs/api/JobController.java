package com.example.jobs.api;

import java.net.URI;
import java.util.List;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Size;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.jobs.domain.Job;
import com.example.jobs.service.JobService;
import com.example.jobs.service.JobService.Caller;
import com.example.jobs.service.SubmitJobCommand;
import com.example.jobs.service.SubmitResult;

/**
 * Every endpoint returns immediately: submission only writes a row and a trigger; the work runs
 * on Quartz worker threads (possibly on another instance).
 */
@RestController
@RequestMapping("/api/jobs")
public class JobController {

    private final JobService jobService;

    public JobController(JobService jobService) {
        this.jobService = jobService;
    }

    /** 201 for a new job, 200 when the Idempotency-Key matched an existing job. */
    @PostMapping
    public ResponseEntity<JobResponse> submit(
            @RequestHeader(name = "Idempotency-Key", required = false) @Size(min = 1, max = 100) String idempotencyKey,
            @Valid @RequestBody SubmitJobRequest request,
            Authentication authentication) {
        int failures = request.simulatedFailures() == null ? 0 : request.simulatedFailures();
        SubmitResult result = jobService.submit(authentication.getName(), idempotencyKey,
                new SubmitJobCommand(request.name(), failures));
        JobResponse body = JobResponse.from(result.job());
        if (result.created()) {
            return ResponseEntity.created(URI.create("/api/jobs/" + body.id())).body(body);
        }
        return ResponseEntity.ok(body);
    }

    @GetMapping("/{id}")
    public JobResponse get(@PathVariable String id, Authentication authentication) {
        return JobResponse.from(jobService.get(id, caller(authentication)));
    }

    @GetMapping
    public PageResponse list(@RequestParam(defaultValue = "0") int page,
                             @RequestParam(defaultValue = "20") int size,
                             Authentication authentication) {
        Page<Job> jobs = jobService.list(caller(authentication),
                PageRequest.of(Math.max(page, 0), Math.min(Math.max(size, 1), 100)));
        return new PageResponse(jobs.map(JobResponse::from).getContent(), jobs.getNumber(), jobs.getSize(),
                jobs.getTotalElements());
    }

    /** 202: the job is CANCELLED already (it was pending) or will be shortly (it was running). */
    @PostMapping("/{id}/cancel")
    public ResponseEntity<JobResponse> cancel(@PathVariable String id, Authentication authentication) {
        Job job = jobService.cancel(id, caller(authentication));
        return ResponseEntity.status(HttpStatus.ACCEPTED).body(JobResponse.from(job));
    }

    static Caller caller(Authentication authentication) {
        boolean admin = authentication.getAuthorities().stream()
                .anyMatch(a -> "ROLE_ADMIN".equals(a.getAuthority()));
        return new Caller(authentication.getName(), admin);
    }

    public record PageResponse(List<JobResponse> items, int page, int size, long total) {
    }
}
