package com.example.jobs.api;

import org.springframework.http.HttpStatus;
import org.springframework.http.ProblemDetail;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.example.jobs.service.IdempotencyConflictException;
import com.example.jobs.service.InvalidJobStateException;
import com.example.jobs.service.JobNotFoundException;
import com.example.jobs.service.QuotaExceededException;

/** Maps domain exceptions to RFC 9457 problem details. */
@RestControllerAdvice
public class ApiExceptionHandler {

    @ExceptionHandler(JobNotFoundException.class)
    ProblemDetail notFound(JobNotFoundException e) {
        return problem(HttpStatus.NOT_FOUND, "Job not found", e.getMessage());
    }

    @ExceptionHandler(IdempotencyConflictException.class)
    ProblemDetail idempotencyConflict(IdempotencyConflictException e) {
        return problem(HttpStatus.UNPROCESSABLE_ENTITY, "Idempotency key reused", e.getMessage());
    }

    @ExceptionHandler(InvalidJobStateException.class)
    ProblemDetail invalidState(InvalidJobStateException e) {
        return problem(HttpStatus.CONFLICT, "Invalid job state", e.getMessage());
    }

    @ExceptionHandler(QuotaExceededException.class)
    ProblemDetail quota(QuotaExceededException e) {
        return problem(HttpStatus.TOO_MANY_REQUESTS, "Active job quota exceeded", e.getMessage());
    }

    private static ProblemDetail problem(HttpStatus status, String title, String detail) {
        ProblemDetail pd = ProblemDetail.forStatusAndDetail(status, detail);
        pd.setTitle(title);
        return pd;
    }
}
