package com.example.jobs.execution;

import java.time.Instant;
import java.util.Date;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.JobExecutionContext;
import org.quartz.JobKey;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.SimpleScheduleBuilder;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.springframework.stereotype.Component;

/**
 * Thin facade over the clustered Quartz scheduler. Quartz is used as a durable, cluster-aware
 * dispatch queue: one JobDetail per domain job, one one-shot trigger per attempt.
 *
 * <p>Because Spring Boot wires Quartz with {@code LocalDataSourceJobStore}, these calls join the
 * caller's Spring transaction: a job row and its trigger are committed (or rolled back) together.
 */
@Component
public class QuartzJobScheduler {

    public static final String GROUP = "jobs";

    private final Scheduler scheduler;

    public QuartzJobScheduler(Scheduler scheduler) {
        this.scheduler = scheduler;
    }

    /** Identity of this node in the Quartz cluster; also recorded as {@code jobs.worker_instance}. */
    public String instanceId() {
        try {
            return scheduler.getSchedulerInstanceId();
        } catch (SchedulerException e) {
            throw new IllegalStateException(e);
        }
    }

    /** Schedule an attempt for the job at {@code at}; creates the Quartz JobDetail if needed. */
    public void scheduleAttempt(String jobId, Instant at) {
        JobKey key = key(jobId);
        Trigger trigger = TriggerBuilder.newTrigger()
                .withIdentity(jobId + "-" + UUID.randomUUID().toString().substring(0, 8), GROUP)
                .forJob(key)
                .startAt(Date.from(at))
                // If all worker threads in the cluster are busy past the misfire threshold, run as soon as possible.
                .withSchedule(SimpleScheduleBuilder.simpleSchedule().withMisfireHandlingInstructionFireNow())
                .build();
        try {
            if (scheduler.checkExists(key)) {
                scheduler.scheduleJob(trigger);
            } else {
                JobDetail detail = JobBuilder.newJob(SimulatedWorkJob.class)
                        .withIdentity(key)
                        // Re-fire on another node if the executing node dies mid-job.
                        .requestRecovery(true)
                        .storeDurably(false)
                        .build();
                scheduler.scheduleJob(detail, trigger);
            }
        } catch (SchedulerException e) {
            throw new IllegalStateException("Could not schedule job " + jobId, e);
        }
    }

    /** Remove the job and all of its pending triggers (used when cancelling a pending job). */
    public void unschedule(String jobId) {
        try {
            scheduler.deleteJob(key(jobId));
        } catch (SchedulerException e) {
            throw new IllegalStateException("Could not unschedule job " + jobId, e);
        }
    }

    /** Interrupt the job if it is executing on THIS node. Returns true if it was found. */
    public boolean interruptLocal(String jobId) {
        try {
            return scheduler.interrupt(key(jobId));
        } catch (SchedulerException e) {
            throw new IllegalStateException(e);
        }
    }

    /** Ids of jobs currently executing on this node. */
    public Set<String> locallyExecutingJobIds() {
        try {
            return scheduler.getCurrentlyExecutingJobs().stream()
                    .map(JobExecutionContext::getJobDetail)
                    .map(d -> d.getKey().getName())
                    .collect(Collectors.toSet());
        } catch (SchedulerException e) {
            throw new IllegalStateException(e);
        }
    }

    private static JobKey key(String jobId) {
        return JobKey.jobKey(jobId, GROUP);
    }
}
