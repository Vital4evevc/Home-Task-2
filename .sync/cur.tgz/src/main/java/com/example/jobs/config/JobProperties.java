package com.example.jobs.config;

import java.time.Duration;
import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * All tunables of the job service, bound from the {@code jobs.*} namespace.
 */
@ConfigurationProperties("jobs")
public record JobProperties(
        Work work,
        Retry retry,
        Limits limits,
        RateLimit rateLimit,
        Cancellation cancellation,
        Shutdown shutdown,
        Security security) {

    /** Simulated work: each attempt sleeps a random duration in [minDuration, maxDuration]. */
    public record Work(Duration minDuration, Duration maxDuration, double randomFailureRate) {
    }

    /** Retry policy: exponential backoff, {@code maxAttempts} includes the first attempt. */
    public record Retry(int maxAttempts, Duration initialBackoff, double multiplier) {
    }

    /** Admission limits applied at submission time. */
    public record Limits(int maxActiveJobsPerUser) {
    }

    /** Token bucket per user for job submissions. */
    public record RateLimit(int capacity, int refillPerMinute) {
    }

    public record Cancellation(Duration pollInterval) {
    }

    public record Shutdown(Duration requeueWait) {
    }

    public record Security(List<User> users) {
        public record User(String username, String password, List<String> roles) {
        }
    }
}
