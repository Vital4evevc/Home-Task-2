package com.example.jobs.observability;

import java.util.EnumMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import org.springframework.stereotype.Component;

import com.example.jobs.domain.JobRepository;
import com.example.jobs.domain.JobStatus;

import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.Gauge;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Timer;

/**
 * Exposed at /actuator/prometheus (and /actuator/metrics). Counters and the local gauge are
 * per-instance; {@code jobs.count{status}} reads the shared DB so every instance reports the
 * cluster-wide queue depth.
 */
@Component
public class JobMetrics {

    private final AtomicInteger running = new AtomicInteger();
    private final Counter submitted;
    private final Counter idempotentReplays;
    private final Counter rateLimited;
    private final Counter retried;
    private final Counter recovered;
    private final Map<JobStatus, Counter> finished = new EnumMap<>(JobStatus.class);
    private final Timer execution;

    public JobMetrics(MeterRegistry registry, JobRepository repository) {
        submitted = Counter.builder("jobs.submitted").register(registry);
        idempotentReplays = Counter.builder("jobs.submitted.replayed")
                .description("Submissions answered from an existing job via Idempotency-Key").register(registry);
        rateLimited = Counter.builder("jobs.submissions.rate_limited").register(registry);
        retried = Counter.builder("jobs.retries").register(registry);
        recovered = Counter.builder("jobs.recovered")
                .description("Jobs re-fired after the node executing them died").register(registry);
        for (JobStatus s : new JobStatus[] {JobStatus.SUCCEEDED, JobStatus.FAILED, JobStatus.CANCELLED}) {
            finished.put(s, Counter.builder("jobs.finished").tag("outcome", s.name().toLowerCase()).register(registry));
        }
        execution = Timer.builder("jobs.execution").description("Wall time of one execution attempt").register(registry);
        Gauge.builder("jobs.running.local", running, AtomicInteger::get)
                .description("Jobs executing on this instance").register(registry);
        for (JobStatus s : JobStatus.values()) {
            Gauge.builder("jobs.count", repository, r -> r.countByStatus(s))
                    .tag("status", s.name().toLowerCase())
                    .strongReference(true)
                    .register(registry);
        }
    }

    public AtomicInteger running() { return running; }
    public void submitted() { submitted.increment(); }
    public void replayed() { idempotentReplays.increment(); }
    public void rateLimited() { rateLimited.increment(); }
    public void retried() { retried.increment(); }
    public void recovered() { recovered.increment(); }
    public void finished(JobStatus outcome) { finished.get(outcome).increment(); }
    public void recordExecution(long nanos) { execution.record(nanos, TimeUnit.NANOSECONDS); }
}
