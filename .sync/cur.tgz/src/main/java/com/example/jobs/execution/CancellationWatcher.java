package com.example.jobs.execution;

import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.example.jobs.domain.JobRepository;

/**
 * Cancellation of a RUNNING job is a cross-node problem: the API request may land on node A while
 * the job sleeps on node B. The API only sets {@code cancel_requested}; every node periodically
 * checks the jobs it is executing locally and interrupts those that were flagged.
 * One cheap indexed query per node per interval, independent of the number of jobs.
 */
@Component
public class CancellationWatcher {

    private static final Logger log = LoggerFactory.getLogger(CancellationWatcher.class);

    private final QuartzJobScheduler scheduler;
    private final JobRepository repository;

    public CancellationWatcher(QuartzJobScheduler scheduler, JobRepository repository) {
        this.scheduler = scheduler;
        this.repository = repository;
    }

    @Scheduled(fixedDelayString = "${jobs.cancellation.poll-interval}")
    public void interruptCancelledJobs() {
        Set<String> local = scheduler.locallyExecutingJobIds();
        if (local.isEmpty()) {
            return;
        }
        for (String jobId : repository.findCancelRequestedAmong(local)) {
            if (scheduler.interruptLocal(jobId)) {
                log.info("Interrupting job {} (cancellation requested)", jobId);
            }
        }
    }
}
