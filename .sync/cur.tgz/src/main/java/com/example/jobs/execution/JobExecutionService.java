package com.example.jobs.execution;

import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.util.EnumSet;
import java.util.Optional;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.jobs.config.JobProperties;
import com.example.jobs.domain.Job;
import com.example.jobs.domain.JobRepository;
import com.example.jobs.domain.JobStatus;
import com.example.jobs.observability.JobMetrics;

/**
 * Worker-side state machine. Each method is one short transaction; the long sleep happens
 * outside any transaction so no DB connection or lock is held while a job "works".
 */
@Service
public class JobExecutionService {

    private static final Logger log = LoggerFactory.getLogger(JobExecutionService.class);
    private static final Set<JobStatus> CLAIMABLE = EnumSet.of(JobStatus.QUEUED, JobStatus.RETRY_PENDING);
    private static final Set<JobStatus> CLAIMABLE_ON_RECOVERY =
            EnumSet.of(JobStatus.QUEUED, JobStatus.RETRY_PENDING, JobStatus.RUNNING);

    private final JobRepository repository;
    private final QuartzJobScheduler scheduler;
    private final WorkSimulator simulator;
    private final JobProperties.Retry retry;
    private final JobMetrics metrics;
    private final Clock clock;

    public JobExecutionService(JobRepository repository, QuartzJobScheduler scheduler, WorkSimulator simulator,
                               JobProperties properties, JobMetrics metrics, Clock clock) {
        this.repository = repository;
        this.scheduler = scheduler;
        this.simulator = simulator;
        this.retry = properties.retry();
        this.metrics = metrics;
        this.clock = clock;
    }

    /**
     * Try to claim the job for this node.
     *
     * @param recovering true when Quartz re-fires the job because the node that ran it died; in that
     *                   case a RUNNING row (owned by the dead node) may be taken over.
     * @return the attempt to execute, or empty if the job must not run (cancelled, already finished,
     *         claimed elsewhere, or out of attempts).
     */
    @Transactional
    public Optional<Attempt> start(String jobId, boolean recovering) {
        Instant now = clock.instant();
        Duration duration = simulator.pickDuration();
        String instance = scheduler.instanceId();

        int claimed = repository.claim(jobId, instance, duration.toMillis(), now,
                recovering ? CLAIMABLE_ON_RECOVERY : CLAIMABLE);
        Optional<Job> loaded = repository.findById(jobId);
        if (loaded.isEmpty()) {
            log.warn("Fired for unknown job {}, ignoring", jobId);
            return Optional.empty();
        }
        Job job = loaded.get();

        if (claimed == 0) {
            if (job.isCancelRequested() && !job.getStatus().isTerminal()) {
                // e.g. the node died after cancel was requested but before it could interrupt
                repository.markCancelled(jobId, JobStatus.ACTIVE, now);
                metrics.finished(JobStatus.CANCELLED);
                log.info("Job {} was cancel-requested; marked CANCELLED instead of running", jobId);
            } else {
                log.info("Job {} not claimable (status={}), skipping fire", jobId, job.getStatus());
            }
            return Optional.empty();
        }

        if (recovering) {
            metrics.recovered();
            log.warn("Recovering job {} after node failure; this is attempt {}/{}",
                    jobId, job.getAttempts(), job.getMaxAttempts());
            if (job.getAttempts() > job.getMaxAttempts()) {
                repository.markFailed(jobId, EnumSet.of(JobStatus.RUNNING),
                        "Interrupted by node failure and no attempts left", now);
                metrics.finished(JobStatus.FAILED);
                return Optional.empty();
            }
        }

        log.info("Job {} started on {} (attempt {}/{}, planned {} ms)",
                jobId, instance, job.getAttempts(), job.getMaxAttempts(), duration.toMillis());
        return Optional.of(new Attempt(jobId, job.getAttempts(), duration,
                job.getAttempts() <= job.getSimulatedFailures()));
    }

    @Transactional
    public void succeed(Attempt attempt) {
        Instant now = clock.instant();
        String result = "Completed after " + attempt.duration().toMillis() + " ms";
        if (repository.markSucceeded(attempt.jobId(), scheduler.instanceId(), result, now) == 1) {
            metrics.finished(JobStatus.SUCCEEDED);
            log.info("Job {} succeeded", attempt.jobId());
            return;
        }
        // Cancellation was requested while the work was finishing: honour it.
        cancelIfRequested(attempt.jobId(), now);
    }

    @Transactional
    public void fail(Attempt attempt, Exception error) {
        Instant now = clock.instant();
        String jobId = attempt.jobId();
        String message = truncate(error.getClass().getSimpleName() + ": " + error.getMessage());
        Job job = repository.findById(jobId).orElseThrow();

        if (job.isCancelRequested()) {
            cancelIfRequested(jobId, now);
            return;
        }
        if (attempt.number() < job.getMaxAttempts()) {
            Duration backoff = backoff(attempt.number());
            Instant next = now.plus(backoff);
            if (repository.markRetryPending(jobId, scheduler.instanceId(), message, next, now) == 1) {
                scheduler.scheduleAttempt(jobId, next);   // same transaction as the state change
                metrics.retried();
                log.warn("Job {} attempt {} failed ({}); retrying in {} ms",
                        jobId, attempt.number(), message, backoff.toMillis());
            } else {
                cancelIfRequested(jobId, now); // cancel arrived between the read above and the update
            }
        } else {
            repository.markFailed(jobId, EnumSet.of(JobStatus.RUNNING), message, now);
            metrics.finished(JobStatus.FAILED);
            log.error("Job {} failed permanently after {} attempts: {}", jobId, attempt.number(), message);
        }
    }

    /** Worker thread was interrupted: either a cancellation or this node shutting down. */
    @Transactional
    public void interrupted(Attempt attempt, boolean shuttingDown) {
        Instant now = clock.instant();
        String jobId = attempt.jobId();
        if (cancelIfRequested(jobId, now)) {
            return;
        }
        if (shuttingDown && repository.requeue(jobId, scheduler.instanceId(), now) == 1) {
            scheduler.scheduleAttempt(jobId, now);
            log.info("Job {} handed back to the queue because this node is shutting down", jobId);
            return;
        }
        fail(attempt, new InterruptedException("Worker interrupted unexpectedly"));
    }

    private boolean cancelIfRequested(String jobId, Instant now) {
        Job job = repository.findById(jobId).orElseThrow();
        if (job.isCancelRequested()
                && repository.markCancelled(jobId, EnumSet.of(JobStatus.RUNNING), now) == 1) {
            metrics.finished(JobStatus.CANCELLED);
            log.info("Job {} cancelled while running", jobId);
            return true;
        }
        return false;
    }

    Duration backoff(int attemptNumber) {
        double factor = Math.pow(retry.multiplier(), attemptNumber - 1);
        return Duration.ofMillis((long) (retry.initialBackoff().toMillis() * factor));
    }

    private static String truncate(String s) {
        return s.length() <= 1000 ? s : s.substring(0, 1000);
    }
}
