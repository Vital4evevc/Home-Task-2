package com.example.jobs.api;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

/**
 * @param simulatedFailures optional demo/test hook: number of initial attempts that should fail,
 *                          to exercise the retry path deterministically.
 */
public record SubmitJobRequest(
        @NotBlank @Size(max = 200) String name,
        @Min(0) @Max(10) Integer simulatedFailures) {
}
