package com.example.jobs.service;

public class JobNotFoundException extends RuntimeException {
    public JobNotFoundException(String id) {
        super("Job " + id + " not found");
    }
}
