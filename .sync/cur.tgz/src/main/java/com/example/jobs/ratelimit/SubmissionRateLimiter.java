package com.example.jobs.ratelimit;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.function.LongSupplier;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.jobs.config.JobProperties;

/**
 * Per-user token bucket for job submissions, held in memory.
 *
 * <p>Trade-off: with N instances behind a round-robin load balancer the effective limit is up to
 * N x capacity. Acceptable as a first line of defence; the active-job quota in JobService is
 * enforced against the shared DB and is cluster-wide. For an exact cluster-wide limit, back the
 * buckets with Redis (Bucket4j + Lettuce) - see README.
 */
@Component
public class SubmissionRateLimiter {

    private final ConcurrentMap<String, TokenBucket> buckets = new ConcurrentHashMap<>();
    private final int capacity;
    private final double refillPerSecond;
    private final LongSupplier nanoClock;

    @Autowired
    public SubmissionRateLimiter(JobProperties properties) {
        this(properties.rateLimit().capacity(), properties.rateLimit().refillPerMinute(), System::nanoTime);
    }

    SubmissionRateLimiter(int capacity, int refillPerMinute, LongSupplier nanoClock) {
        this.capacity = capacity;
        this.refillPerSecond = refillPerMinute / 60d;
        this.nanoClock = nanoClock;
    }

    /** @return 0 if allowed, otherwise the number of seconds the caller should wait. */
    public long tryAcquire(String user) {
        long now = nanoClock.getAsLong();
        long waitNanos = buckets
                .computeIfAbsent(user, u -> new TokenBucket(capacity, refillPerSecond, now))
                .tryConsume(now);
        return waitNanos == 0 ? 0 : Math.max(1, (long) Math.ceil(waitNanos / 1_000_000_000d));
    }
}
