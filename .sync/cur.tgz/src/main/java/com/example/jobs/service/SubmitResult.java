package com.example.jobs.service;

import com.example.jobs.domain.Job;

/** @param created false when the job already existed for this Idempotency-Key (a replay). */
public record SubmitResult(Job job, boolean created) {
}
