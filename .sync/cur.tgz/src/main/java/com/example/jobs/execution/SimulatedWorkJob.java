package com.example.jobs.execution;

import java.util.Optional;

import org.quartz.DisallowConcurrentExecution;
import org.quartz.InterruptableJob;
import org.quartz.JobExecutionContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import com.example.jobs.observability.JobMetrics;

/**
 * The Quartz job. Runs on a Quartz worker thread, never on a request thread, so the API stays
 * responsive. The Quartz thread pool size is the per-instance concurrency limit.
 *
 * <p>{@code @DisallowConcurrentExecution} guarantees that, cluster-wide, two triggers of the same
 * job (e.g. a retry fired while the previous attempt is still unwinding) never overlap.
 */
@DisallowConcurrentExecution
public class SimulatedWorkJob implements InterruptableJob {

    private static final Logger log = LoggerFactory.getLogger(SimulatedWorkJob.class);

    private final JobExecutionService executionService;
    private final WorkSimulator simulator;
    private final ShutdownState shutdownState;
    private final JobMetrics metrics;

    private volatile Thread worker;

    public SimulatedWorkJob(JobExecutionService executionService, WorkSimulator simulator,
                            ShutdownState shutdownState, JobMetrics metrics) {
        this.executionService = executionService;
        this.simulator = simulator;
        this.shutdownState = shutdownState;
        this.metrics = metrics;
    }

    @Override
    public void execute(JobExecutionContext context) {
        String jobId = context.getJobDetail().getKey().getName();
        MDC.put("jobId", jobId);
        worker = Thread.currentThread();
        try {
            Optional<Attempt> claimed = executionService.start(jobId, context.isRecovering());
            if (claimed.isEmpty()) {
                return;
            }
            Attempt attempt = claimed.get();
            metrics.running().incrementAndGet();
            long startNanos = System.nanoTime();
            try {
                simulator.perform(attempt.duration(), attempt.forceFailure());
                executionService.succeed(attempt);
            } catch (InterruptedException e) {
                Thread.interrupted(); // clear the flag so the DB work below is not disturbed
                executionService.interrupted(attempt, shutdownState.isShuttingDown());
            } catch (Exception e) {
                executionService.fail(attempt, e);
            } finally {
                metrics.running().decrementAndGet();
                metrics.recordExecution(System.nanoTime() - startNanos);
            }
        } catch (RuntimeException e) {
            // State transition failed (e.g. DB unavailable). Leaving the row RUNNING is safe:
            // see README "Known gaps" for the stale-RUNNING reconciler that would pick it up.
            log.error("Unexpected error while handling job {}", jobId, e);
        } finally {
            worker = null;
            MDC.remove("jobId");
        }
    }

    @Override
    public void interrupt() {
        Thread t = worker;
        if (t != null) {
            t.interrupt();
        }
    }
}
